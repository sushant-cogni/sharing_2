import { validateToken } from "#utils"

export const Authenticate = async(req,res,next) => {

    const token = req.cookies.token

    if(!token)
        return res.redirect("/signin")

    try{
        const payload = validateToken(token)

        if(payload)
            req.user=payload
    }catch(err){}

    return next()

}