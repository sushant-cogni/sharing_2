import express from "express"
import {config} from "dotenv"
import {connectDB, printlogs}  from "#utils"
import path from "path"
import {usersRoutes} from "#routes"
import cookieParser from  "cookie-parser"
import { Authenticate } from "#middlewares"

config()

const app = express()
app.listen(process.env.PORT || 5000, ()=>{
    console.log(`Server Started at PORT : ${process.env.PORT}`)
})

connectDB()

app.set("view engine","ejs")
app.set("views",path.resolve("./views"))

app.use(printlogs)
app.use(express.urlencoded({extended:false}))
app.use(express.json())
app.use(cookieParser())



app.get("/signup",(req,res) => {
    return res.render("signup")
})

app.get("/signin",(req,res) => {
    return res.render("signin")
})

app.use("/auth",usersRoutes)

app.use(Authenticate)
app.get("/",(req,res) =>{
    return res.render("home",{
        user:req.user
    })
})