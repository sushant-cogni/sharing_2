import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../services/api";

export default function Register() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirm: "",
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm)
      return toast.error("Passwords do not match");
    if (form.password.length < 6)
      return toast.error("Password must be at least 6 characters");
    setLoading(true);
    try {
      await api.post("/auth/register", {
        name: form.name,
        email: form.email,
        password: form.password,
      });
      toast.success("Registered! Please login.");
      navigate("/login");
    } catch (err) {
      toast.error(err.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={S.page}>
      <div style={S.card}>
        <h2 style={S.title}>📚 Create Account</h2>
        <p style={S.sub}>Join BookApp today</p>

        <form onSubmit={handleSubmit} style={S.form}>
          <input
            name="name"
            placeholder="Full Name"
            value={form.name}
            onChange={handleChange}
            style={S.input}
            required
          />
          <input
            name="email"
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
            style={S.input}
            required
          />
          <input
            name="password"
            type="password"
            placeholder="Password (min 6)"
            value={form.password}
            onChange={handleChange}
            style={S.input}
            required
          />
          <input
            name="confirm"
            type="password"
            placeholder="Confirm Password"
            value={form.confirm}
            onChange={handleChange}
            style={S.input}
            required
          />
          <button type="submit" disabled={loading} style={S.btn}>
            {loading ? "Creating..." : "Create Account"}
          </button>
        </form>

        <p style={S.footer}>
          Already registered?{" "}
          <Link to="/login" style={S.link}>
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}

const S = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
    background: "#0f1117",
  },
  card: {
    background: "#13151f",
    borderRadius: 20,
    padding: 40,
    width: "100%",
    maxWidth: 420,
    border: "1px solid #2d2f3e",
  },
  title: {
    fontSize: "1.8rem",
    fontWeight: 800,
    color: "#e2e8f0",
    textAlign: "center",
    marginBottom: 6,
  },
  sub: {
    color: "#64748b",
    textAlign: "center",
    marginBottom: 28,
    fontSize: "0.9rem",
  },
  form: { display: "flex", flexDirection: "column", gap: 14 },
  input: {
    padding: "12px 16px",
    background: "#1a1d2e",
    border: "1px solid #2d2f3e",
    borderRadius: 10,
    color: "#e2e8f0",
    fontSize: "0.95rem",
    outline: "none",
  },
  btn: {
    padding: 13,
    background: "#6366f1",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    fontWeight: 600,
    fontSize: "1rem",
    cursor: "pointer",
    marginTop: 4,
  },
  footer: {
    textAlign: "center",
    marginTop: 20,
    color: "#64748b",
    fontSize: "0.9rem",
  },
  link: { color: "#6366f1", fontWeight: 600 },
};
