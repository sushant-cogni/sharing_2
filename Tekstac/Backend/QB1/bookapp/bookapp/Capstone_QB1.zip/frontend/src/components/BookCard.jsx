import React from "react";
import { useNavigate } from "react-router-dom";

const PLACEHOLDER = "https://via.placeholder.com/120x180?text=No+Cover";

export default function BookCard({ book, isFav, isRec, onFav, onRec }) {
  const navigate = useNavigate();

  return (
    <div style={S.card} onClick={() => navigate(`/book/${book.id}`)}>
      {/* Cover */}
      <div style={S.imgWrap}>
        <img
          src={book.thumbnail || PLACEHOLDER}
          alt={book.title}
          style={S.img}
          onError={(e) => {
            e.target.src = PLACEHOLDER;
          }}
        />
      </div>

      {/* Info */}
      <div style={S.info}>
        <p style={S.title}>{book.title}</p>
        <p style={S.author}>{book.authors?.[0]}</p>
        {book.averageRating && <p style={S.rating}>⭐ {book.averageRating}</p>}
      </div>

      {/* Actions */}
      <div style={S.actions} onClick={(e) => e.stopPropagation()}>
        {onFav && (
          <button
            onClick={() => onFav(book)}
            style={{ ...S.iconBtn, color: isFav ? "#ef4444" : "#64748b" }}
            title={isFav ? "Remove Favourite" : "Add Favourite"}
          >
            {isFav ? "❤️" : "🤍"}
          </button>
        )}
        {onRec && (
          <button
            onClick={() => onRec(book)}
            style={{ ...S.iconBtn, color: isRec ? "#f59e0b" : "#64748b" }}
            title={isRec ? "Remove Recommendation" : "Recommend"}
          >
            {isRec ? "⭐" : "☆"}
          </button>
        )}
        <button onClick={() => navigate(`/book/${book.id}`)} style={S.viewBtn}>
          View
        </button>
      </div>
    </div>
  );
}

const S = {
  card: {
    background: "#1a1d2e",
    borderRadius: 14,
    overflow: "hidden",
    border: "1px solid #2d2f3e",
    cursor: "pointer",
    display: "flex",
    flexDirection: "column",
    transition: "transform 0.2s",
  },
  imgWrap: {
    background: "#0f1117",
    display: "flex",
    justifyContent: "center",
    padding: "16px",
    minHeight: 180,
    alignItems: "center",
  },
  img: { width: 110, height: 165, objectFit: "cover", borderRadius: 6 },
  info: {
    padding: "12px 14px",
    flex: 1,
    display: "flex",
    flexDirection: "column",
    gap: 4,
  },
  title: {
    fontSize: "0.88rem",
    fontWeight: 600,
    color: "#e2e8f0",
    lineHeight: 1.3,
    display: "-webkit-box",
    WebkitLineClamp: 2,
    WebkitBoxOrient: "vertical",
    overflow: "hidden",
  },
  author: {
    fontSize: "0.78rem",
    color: "#6366f1",
    fontWeight: 500,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },
  rating: { fontSize: "0.75rem", color: "#f59e0b" },
  actions: { display: "flex", gap: 6, padding: "0 14px 14px" },
  iconBtn: {
    background: "#0f1117",
    border: "1px solid #2d2f3e",
    borderRadius: 8,
    padding: "5px 10px",
    cursor: "pointer",
    fontSize: "1rem",
  },
  viewBtn: {
    flex: 1,
    background: "rgba(99,102,241,0.12)",
    border: "1px solid #6366f1",
    borderRadius: 8,
    color: "#6366f1",
    padding: "6px",
    cursor: "pointer",
    fontWeight: 600,
    fontSize: "0.8rem",
  },
};
