import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post("/auth/login", form);
      login(res.data.user, res.data.token);
      toast.success(`Welcome back, ${res.data.user.name}!`);
      navigate("/");
    } catch (err) {
      toast.error(err.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={S.page}>
      <div style={S.card}>
        <h2 style={S.title}>📚 Sign In</h2>
        <p style={S.sub}>Access your BookApp account</p>

        <form onSubmit={handleSubmit} style={S.form}>
          <input
            name="email"
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
            style={S.input}
            required
          />
          <input
            name="password"
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            style={S.input}
            required
          />
          <button type="submit" disabled={loading} style={S.btn}>
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <p style={S.footer}>
          No account?{" "}
          <Link to="/register" style={S.link}>
            Register here
          </Link>
        </p>
      </div>
    </div>
  );
}

const S = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
    background: "#0f1117",
  },
  card: {
    background: "#13151f",
    borderRadius: 20,
    padding: 40,
    width: "100%",
    maxWidth: 420,
    border: "1px solid #2d2f3e",
  },
  title: {
    fontSize: "1.8rem",
    fontWeight: 800,
    color: "#e2e8f0",
    textAlign: "center",
    marginBottom: 6,
  },
  sub: {
    color: "#64748b",
    textAlign: "center",
    marginBottom: 28,
    fontSize: "0.9rem",
  },
  form: { display: "flex", flexDirection: "column", gap: 14 },
  input: {
    padding: "12px 16px",
    background: "#1a1d2e",
    border: "1px solid #2d2f3e",
    borderRadius: 10,
    color: "#e2e8f0",
    fontSize: "0.95rem",
    outline: "none",
  },
  btn: {
    padding: 13,
    background: "#6366f1",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    fontWeight: 600,
    fontSize: "1rem",
    cursor: "pointer",
    marginTop: 4,
  },
  footer: {
    textAlign: "center",
    marginTop: 20,
    color: "#64748b",
    fontSize: "0.9rem",
  },
  link: { color: "#6366f1", fontWeight: 600 },
};
