import axios from "axios";

const BASE = process.env.REACT_APP_GOOGLE_BOOKS_API;
const KEY = process.env.REACT_APP_GOOGLE_API_KEY;

export const CATEGORIES = [
  "Fiction",
  "Drama",
  "Comedy",
  "Philosophy",
  "Horror",
  "Thriller",
  "Art",
  "Science",
  "History",
];

export const searchBooks = (query, startIndex = 0) =>
  axios.get(BASE, {
    params: { q: query, key: KEY, startIndex, maxResults: 20 },
  });

export const getBooksByCategory = (category, startIndex = 0) =>
  axios.get(BASE, {
    params: { q: `subject:${category}`, key: KEY, startIndex, maxResults: 20 },
  });

export const getBookById = (id) =>
  axios.get(`${BASE}/${id}`, { params: { key: KEY } });

// Pull out only what we need from a Google Books item
export const extractBook = (item) => ({
  id: item.id,
  title: item.volumeInfo?.title || "Untitled",
  authors: item.volumeInfo?.authors || ["Unknown"],
  thumbnail: item.volumeInfo?.imageLinks?.thumbnail || null,
  description: item.volumeInfo?.description || "",
  publishedDate: item.volumeInfo?.publishedDate || "",
  language: item.volumeInfo?.language || "",
  pageCount: item.volumeInfo?.pageCount || null,
  previewLink: item.volumeInfo?.previewLink || "",
  averageRating: item.volumeInfo?.averageRating || null,
  ratingsCount: item.volumeInfo?.ratingsCount || 0,
  categories: item.volumeInfo?.categories || [],
});
