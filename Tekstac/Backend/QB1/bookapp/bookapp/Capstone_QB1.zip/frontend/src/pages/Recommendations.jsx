import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function Recommendations() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [data, setData] = useState({
    recommendations: [],
    total: 0,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const load = async (p) => {
    setLoading(true);
    try {
      const res = await api.get(`/recommendations?page=${p}&limit=10`);
      setData(res.data);
    } catch {
      toast.error("Failed to load");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(page);
  }, [page]);

  const remove = async (bookId) => {
    try {
      await api.delete(`/recommendations/${bookId}`);
      toast.success("Removed");
      load(page);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed");
    }
  };

  const PH = "https://via.placeholder.com/70x105?text=N/A";

  if (loading)
    return (
      <div className="page-center">
        <div className="spinner" />
      </div>
    );

  return (
    <div style={S.page}>
      <h1 style={S.heading}>
        ⭐ Community Recommendations <span style={S.badge}>{data.total}</span>
      </h1>
      <p style={S.sub}>Books recommended by the BookApp community</p>

      {data.recommendations.length === 0 ? (
        <div className="page-center">
          <p>No recommendations yet.</p>
          <button onClick={() => navigate("/")} style={S.browsBtn}>
            Browse Books
          </button>
        </div>
      ) : (
        <>
          {data.recommendations.map((rec) => (
            <div key={rec._id} style={S.card}>
              <img
                src={rec.thumbnail || PH}
                alt={rec.title}
                style={S.thumb}
                onError={(e) => {
                  e.target.src = PH;
                }}
              />
              <div
                style={S.info}
                onClick={() => navigate(`/book/${rec.bookId}`)}
              >
                <p style={S.title}>{rec.title}</p>
                <p style={S.author}>{rec.authors?.join(", ")}</p>
                {rec.publishedDate && (
                  <p style={S.meta}>📅 {rec.publishedDate.slice(0, 4)}</p>
                )}
              </div>
              <div style={S.actions}>
                <button
                  onClick={() => navigate(`/book/${rec.bookId}`)}
                  style={S.viewBtn}
                >
                  View
                </button>
                {user && rec.userId === user.id && (
                  <button
                    onClick={() => remove(rec.bookId)}
                    style={S.removeBtn}
                  >
                    Remove
                  </button>
                )}
              </div>
            </div>
          ))}

          {data.totalPages > 1 && (
            <div style={S.pagination}>
              {Array.from({ length: data.totalPages }, (_, i) => i + 1).map(
                (p) => (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    style={{
                      ...S.pageBtn,
                      ...(page === p ? S.pageActive : {}),
                    }}
                  >
                    {p}
                  </button>
                ),
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}

const S = {
  page: { maxWidth: 860, margin: "0 auto", padding: "40px 24px 60px" },
  heading: {
    fontSize: "1.8rem",
    fontWeight: 800,
    color: "#e2e8f0",
    marginBottom: 8,
    display: "flex",
    alignItems: "center",
    gap: 12,
    flexWrap: "wrap",
  },
  badge: {
    background: "#1a1d2e",
    border: "1px solid #2d2f3e",
    borderRadius: 20,
    padding: "2px 14px",
    color: "#94a3b8",
    fontSize: "1rem",
  },
  sub: { color: "#64748b", fontSize: "0.9rem", marginBottom: 28 },
  card: {
    display: "flex",
    gap: 20,
    background: "#1a1d2e",
    border: "1px solid #2d2f3e",
    borderRadius: 14,
    padding: 20,
    marginBottom: 14,
    alignItems: "center",
  },
  thumb: {
    width: 70,
    height: 105,
    objectFit: "cover",
    borderRadius: 8,
    flexShrink: 0,
  },
  info: { flex: 1, cursor: "pointer", minWidth: 0 },
  title: {
    fontWeight: 700,
    color: "#e2e8f0",
    marginBottom: 4,
    fontSize: "0.95rem",
  },
  author: {
    color: "#6366f1",
    fontSize: "0.85rem",
    fontWeight: 500,
    marginBottom: 4,
  },
  meta: { color: "#64748b", fontSize: "0.78rem" },
  actions: { display: "flex", gap: 8, flexShrink: 0 },
  viewBtn: {
    padding: "8px 16px",
    background: "rgba(99,102,241,0.12)",
    border: "1px solid #6366f1",
    borderRadius: 8,
    color: "#6366f1",
    cursor: "pointer",
    fontWeight: 600,
    fontSize: "0.82rem",
  },
  removeBtn: {
    padding: "8px 16px",
    background: "rgba(239,68,68,0.1)",
    border: "1px solid #ef4444",
    borderRadius: 8,
    color: "#ef4444",
    cursor: "pointer",
    fontWeight: 600,
    fontSize: "0.82rem",
  },
  browsBtn: {
    marginTop: 16,
    padding: "12px 32px",
    background: "#6366f1",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    cursor: "pointer",
    fontWeight: 600,
  },
  pagination: {
    display: "flex",
    gap: 8,
    justifyContent: "center",
    marginTop: 32,
  },
  pageBtn: {
    padding: "8px 14px",
    background: "#1a1d2e",
    border: "1px solid #2d2f3e",
    borderRadius: 8,
    color: "#94a3b8",
    cursor: "pointer",
  },
  pageActive: { background: "#6366f1", borderColor: "#6366f1", color: "#fff" },
};
