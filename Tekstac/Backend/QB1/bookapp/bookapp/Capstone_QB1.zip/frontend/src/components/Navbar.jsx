import React from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { toast } from "react-toastify";

export default function Navbar() {
  const { user, logout, isAuth } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const active = (path) => ({
    color: pathname === path ? "#6366f1" : "#94a3b8",
    fontWeight: pathname === path ? 600 : 400,
    padding: "8px 14px",
    borderRadius: 8,
    background: pathname === path ? "rgba(99,102,241,0.1)" : "transparent",
    fontSize: "0.9rem",
  });

  const handleLogout = () => {
    logout();
    toast.success("Logged out");
    navigate("/login");
  };

  return (
    <nav style={S.nav}>
      <Link to="/" style={S.logo}>
        📚 BookApp
      </Link>

      <div style={S.links}>
        <Link to="/" style={active("/")}>
          Home
        </Link>

        {isAuth && (
          <>
            <Link to="/favourites" style={active("/favourites")}>
              ❤️ Favourites
            </Link>
            <Link to="/recommendations" style={active("/recommendations")}>
              ⭐ Recommendations
            </Link>
          </>
        )}

        {isAuth ? (
          <>
            <span style={S.name}>👤 {user?.name}</span>
            <button onClick={handleLogout} style={S.logoutBtn}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" style={active("/login")}>
              Login
            </Link>
            <Link to="/register" style={S.regBtn}>
              Register
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}

const S = {
  nav: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "14px 32px",
    background: "#13151f",
    borderBottom: "1px solid #2d2f3e",
    position: "sticky",
    top: 0,
    zIndex: 100,
  },
  logo: { fontSize: "1.4rem", fontWeight: 800, color: "#6366f1" },
  links: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    flexWrap: "wrap",
  },
  name: { color: "#e2e8f0", fontSize: "0.88rem", padding: "0 8px" },
  logoutBtn: {
    background: "transparent",
    border: "1px solid #ef4444",
    color: "#ef4444",
    padding: "7px 14px",
    borderRadius: 8,
    cursor: "pointer",
    fontSize: "0.85rem",
  },
  regBtn: {
    background: "#6366f1",
    color: "#fff",
    padding: "8px 16px",
    borderRadius: 8,
    fontWeight: 600,
    fontSize: "0.88rem",
  },
};
