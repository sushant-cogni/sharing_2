import React, { useState } from "react";

export default function SearchBar({ onSearch }) {
  const [query, setQuery] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) onSearch(query.trim());
  };

  return (
    <form onSubmit={handleSubmit} style={S.form}>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search by title, author, keyword..."
        style={S.input}
      />
      <button type="submit" style={S.btn}>
        🔍 Search
      </button>
    </form>
  );
}

const S = {
  form: { display: "flex", gap: 10, width: "100%", maxWidth: 680 },
  input: {
    flex: 1,
    padding: "12px 18px",
    borderRadius: 10,
    border: "1px solid #2d2f3e",
    background: "#1a1d2e",
    color: "#e2e8f0",
    fontSize: "0.95rem",
    outline: "none",
  },
  btn: {
    padding: "12px 24px",
    background: "#6366f1",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    fontWeight: 600,
    cursor: "pointer",
    fontSize: "0.95rem",
    whiteSpace: "nowrap",
  },
};
