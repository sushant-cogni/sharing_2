import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { getBookById, extractBook } from "../services/bookService";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function BookDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuth } = useAuth();

  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isFav, setIsFav] = useState(false);
  const [isRec, setIsRec] = useState(false);
  const [comments, setComments] = useState([]);
  const [text, setText] = useState("");
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await getBookById(id);
        setBook(extractBook(res.data));
      } catch {
        toast.error("Book not found");
        navigate("/");
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [id, navigate]);

  useEffect(() => {
    if (isAuth) {
      api
        .get(`/favourites/check/${id}`)
        .then((r) => setIsFav(r.data.isFavourite))
        .catch(() => {});
    }
    api
      .get(`/comments/${id}`)
      .then((r) => setComments(r.data))
      .catch(() => {});
  }, [id, isAuth]);

  const toggleFav = async () => {
    if (!isAuth) return toast.info("Please login");
    try {
      if (isFav) {
        await api.delete(`/favourites/${book.id}`);
        setIsFav(false);
        toast.success("Removed from favourites");
      } else {
        await api.post("/favourites", {
          bookId: book.id,
          title: book.title,
          authors: book.authors,
          thumbnail: book.thumbnail,
          description: book.description,
          publishedDate: book.publishedDate,
          language: book.language,
        });
        setIsFav(true);
        toast.success("Added to favourites ❤️");
      }
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed");
    }
  };

  const toggleRec = async () => {
    if (!isAuth) return toast.info("Please login");
    try {
      if (isRec) {
        await api.delete(`/recommendations/${book.id}`);
        setIsRec(false);
        toast.success("Recommendation removed");
      } else {
        await api.post("/recommendations", {
          bookId: book.id,
          title: book.title,
          authors: book.authors,
          thumbnail: book.thumbnail,
          description: book.description,
          publishedDate: book.publishedDate,
          language: book.language,
        });
        setIsRec(true);
        toast.success("Recommended ⭐");
      }
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed");
    }
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!isAuth) return toast.info("Please login");
    if (!text.trim()) return;
    setPosting(true);
    try {
      const res = await api.post("/comments", { bookId: id, text });
      setComments([res.data, ...comments]);
      setText("");
      toast.success("Comment posted!");
    } catch {
      toast.error("Failed to post comment");
    } finally {
      setPosting(false);
    }
  };

  const handleDeleteComment = async (cId) => {
    try {
      await api.delete(`/comments/${cId}`);
      setComments(comments.filter((c) => c._id !== cId));
      toast.success("Comment deleted");
    } catch {
      toast.error("Failed to delete");
    }
  };

  if (loading)
    return (
      <div className="page-center">
        <div className="spinner" />
      </div>
    );
  if (!book) return null;

  const PH = "https://via.placeholder.com/200x300?text=No+Cover";

  return (
    <div style={S.page}>
      <button onClick={() => navigate(-1)} style={S.back}>
        ← Back
      </button>

      {/* Book main info */}
      <div style={S.top}>
        <img
          src={book.thumbnail || PH}
          alt={book.title}
          style={S.cover}
          onError={(e) => {
            e.target.src = PH;
          }}
        />

        <div style={S.info}>
          <h1 style={S.title}>{book.title}</h1>
          <p style={S.author}>{book.authors?.join(", ")}</p>

          {/* Metadata chips */}
          <div style={S.chips}>
            {book.publishedDate && (
              <span style={S.chip}>📅 {book.publishedDate.slice(0, 4)}</span>
            )}
            {book.language && (
              <span style={S.chip}>🌐 {book.language.toUpperCase()}</span>
            )}
            {book.pageCount && (
              <span style={S.chip}>📄 {book.pageCount} pages</span>
            )}
            {book.averageRating && (
              <span style={S.chip}>⭐ {book.averageRating}</span>
            )}
          </div>

          {/* Action buttons */}
          <div style={S.btns}>
            <button
              onClick={toggleFav}
              style={{ ...S.btn, ...(isFav ? S.favActive : {}) }}
            >
              {isFav ? "❤️ Remove Favourite" : "🤍 Add to Favourites"}
            </button>
            <button
              onClick={toggleRec}
              style={{ ...S.btn, ...(isRec ? S.recActive : {}) }}
            >
              {isRec ? "⭐ Recommended" : "☆ Recommend"}
            </button>
            {book.previewLink && (
              <a
                href={book.previewLink}
                target="_blank"
                rel="noreferrer"
                style={S.previewLink}
              >
                📖 Preview Book
              </a>
            )}
          </div>

          {/* Description */}
          {book.description && (
            <div style={S.descBox}>
              <h3 style={S.descTitle}>About this book</h3>
              <p
                style={S.desc}
                dangerouslySetInnerHTML={{ __html: book.description }}
              />
            </div>
          )}
        </div>
      </div>

      {/* Comments */}
      <div style={S.commentSection}>
        <h2 style={S.commentHeading}>💬 Comments ({comments.length})</h2>

        {isAuth ? (
          <form onSubmit={handleComment} style={S.commentForm}>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Share your thoughts..."
              style={S.textarea}
              rows={3}
              maxLength={1000}
            />
            <div style={S.commentActions}>
              <span style={{ color: "#64748b", fontSize: "0.8rem" }}>
                {text.length}/1000
              </span>
              <button
                type="submit"
                disabled={posting || !text.trim()}
                style={S.postBtn}
              >
                {posting ? "Posting..." : "Post Comment"}
              </button>
            </div>
          </form>
        ) : (
          <p style={{ color: "#64748b", marginBottom: 24 }}>
            <a href="/login" style={{ color: "#6366f1" }}>
              Login
            </a>{" "}
            to comment
          </p>
        )}

        {/* Comment list */}
        {comments.length === 0 ? (
          <p
            style={{ color: "#64748b", textAlign: "center", padding: "32px 0" }}
          >
            No comments yet. Be the first!
          </p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {comments.map((c) => (
              <div key={c._id} style={S.commentCard}>
                <div style={S.commentHeader}>
                  <span style={S.commentUser}>👤 {c.userName}</span>
                  <span style={{ color: "#64748b", fontSize: "0.78rem" }}>
                    {new Date(c.createdAt).toLocaleDateString()}
                  </span>
                  {user && c.userId === user.id && (
                    <button
                      onClick={() => handleDeleteComment(c._id)}
                      style={S.delBtn}
                    >
                      🗑️
                    </button>
                  )}
                </div>
                <p
                  style={{
                    color: "#94a3b8",
                    lineHeight: 1.6,
                    fontSize: "0.9rem",
                  }}
                >
                  {c.text}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const S = {
  page: { maxWidth: 1100, margin: "0 auto", padding: "32px 24px 60px" },
  back: {
    background: "none",
    border: "none",
    color: "#6366f1",
    cursor: "pointer",
    fontWeight: 600,
    marginBottom: 24,
    padding: 0,
    fontSize: "0.95rem",
  },
  top: { display: "flex", gap: 40, marginBottom: 48, flexWrap: "wrap" },
  cover: {
    width: 200,
    height: 300,
    objectFit: "cover",
    borderRadius: 12,
    flexShrink: 0,
    boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
  },
  info: { flex: 1, minWidth: 260 },
  title: {
    fontSize: "1.8rem",
    fontWeight: 800,
    color: "#e2e8f0",
    marginBottom: 8,
    lineHeight: 1.3,
  },
  author: {
    color: "#6366f1",
    fontSize: "1rem",
    fontWeight: 500,
    marginBottom: 16,
  },
  chips: { display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 },
  chip: {
    background: "#1a1d2e",
    border: "1px solid #2d2f3e",
    borderRadius: 20,
    padding: "4px 12px",
    fontSize: "0.78rem",
    color: "#94a3b8",
  },
  btns: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 24 },
  btn: {
    padding: "10px 18px",
    border: "1px solid #2d2f3e",
    borderRadius: 10,
    background: "#1a1d2e",
    color: "#e2e8f0",
    cursor: "pointer",
    fontSize: "0.88rem",
  },
  favActive: {
    background: "rgba(239,68,68,0.12)",
    borderColor: "#ef4444",
    color: "#ef4444",
  },
  recActive: {
    background: "rgba(245,158,11,0.12)",
    borderColor: "#f59e0b",
    color: "#f59e0b",
  },
  previewLink: {
    padding: "10px 18px",
    background: "rgba(99,102,241,0.12)",
    border: "1px solid #6366f1",
    borderRadius: 10,
    color: "#6366f1",
    fontWeight: 600,
    fontSize: "0.88rem",
  },
  descBox: { marginTop: 8 },
  descTitle: {
    fontSize: "1rem",
    fontWeight: 700,
    color: "#e2e8f0",
    marginBottom: 8,
  },
  desc: { color: "#94a3b8", lineHeight: 1.8, fontSize: "0.9rem" },
  commentSection: { borderTop: "1px solid #2d2f3e", paddingTop: 40 },
  commentHeading: {
    fontSize: "1.2rem",
    fontWeight: 700,
    color: "#e2e8f0",
    marginBottom: 20,
  },
  commentForm: { marginBottom: 28 },
  textarea: {
    width: "100%",
    padding: "13px 16px",
    background: "#1a1d2e",
    border: "1px solid #2d2f3e",
    borderRadius: 12,
    color: "#e2e8f0",
    fontSize: "0.95rem",
    outline: "none",
    resize: "vertical",
  },
  commentActions: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 10,
  },
  postBtn: {
    padding: "9px 22px",
    background: "#6366f1",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    fontWeight: 600,
    cursor: "pointer",
  },
  commentCard: {
    background: "#1a1d2e",
    borderRadius: 12,
    padding: "16px 20px",
    border: "1px solid #2d2f3e",
  },
  commentHeader: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    marginBottom: 8,
  },
  commentUser: { color: "#6366f1", fontWeight: 600, fontSize: "0.88rem" },
  delBtn: {
    background: "none",
    border: "none",
    cursor: "pointer",
    marginLeft: "auto",
    fontSize: "0.9rem",
  },
};
