import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./assets/styles.css";

import { AuthProvider, useAuth } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import BookDetail from "./pages/BookDetail";
import Favourites from "./pages/Favourites";
import Recommendations from "./pages/Recommendations";

// Wrapper: only logged-in users can access this route
const Private = ({ children }) => {
  const { isAuth, loading } = useAuth();
  if (loading)
    return (
      <div className="page-center">
        <div className="spinner" />
      </div>
    );
  return isAuth ? children : <Navigate to="/login" replace />;
};

function AppRoutes() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/book/:id" element={<BookDetail />} />
        <Route
          path="/favourites"
          element={
            <Private>
              <Favourites />
            </Private>
          }
        />
        <Route
          path="/recommendations"
          element={
            <Private>
              <Recommendations />
            </Private>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
        <ToastContainer position="top-right" autoClose={3000} />
      </BrowserRouter>
    </AuthProvider>
  );
}
