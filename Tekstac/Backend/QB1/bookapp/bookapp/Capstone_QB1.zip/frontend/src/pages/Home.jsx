import React, { useState, useEffect, useCallback } from "react";
import { toast } from "react-toastify";
import SearchBar from "../components/SearchBar";
import BookCard from "../components/BookCard";
import {
  searchBooks,
  getBooksByCategory,
  extractBook,
  CATEGORIES,
} from "../services/bookService";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function Home() {
  const { isAuth } = useAuth();
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState("Fiction");
  const [query, setQuery] = useState("");
  const [startIndex, setStartIndex] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [favIds, setFavIds] = useState(new Set());
  const [recIds, setRecIds] = useState(new Set());

  // Load user's fav & rec IDs so cards show correct icons
  const loadUserData = useCallback(async () => {
    if (!isAuth) return;
    try {
      const [favRes, recRes] = await Promise.all([
        api.get("/favourites"),
        api.get("/recommendations"),
      ]);
      setFavIds(new Set(favRes.data.favourites.map((f) => f.bookId)));
      setRecIds(new Set(recRes.data.recommendations.map((r) => r.bookId)));
    } catch {
      /* silent */
    }
  }, [isAuth]);

  // Fetch books from Google Books
  const loadBooks = useCallback(async (cat, q, idx) => {
    setLoading(true);
    try {
      const res = q
        ? await searchBooks(q, idx)
        : await getBooksByCategory(cat, idx);
      const items = (res.data.items || []).map(extractBook);
      setBooks(idx === 0 ? items : (prev) => [...prev, ...items]);
      setTotalItems(res.data.totalItems || 0);
    } catch {
      toast.error("Failed to load books");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    setStartIndex(0);
    setBooks([]);
    loadBooks(category, query, 0);
  }, [category, query, loadBooks]);

  useEffect(() => {
    loadUserData();
  }, [loadUserData]);

  const handleSearch = (q) => {
    setQuery(q);
    setCategory("");
  };
  const handleCategory = (cat) => {
    setCategory(cat);
    setQuery("");
  };

  const handleFav = async (book) => {
    if (!isAuth) return toast.info("Please login first");
    try {
      if (favIds.has(book.id)) {
        await api.delete(`/favourites/${book.id}`);
        setFavIds((p) => {
          const s = new Set(p);
          s.delete(book.id);
          return s;
        });
        toast.success("Removed from favourites");
      } else {
        await api.post("/favourites", {
          bookId: book.id,
          title: book.title,
          authors: book.authors,
          thumbnail: book.thumbnail,
          description: book.description,
          publishedDate: book.publishedDate,
          language: book.language,
        });
        setFavIds((p) => new Set([...p, book.id]));
        toast.success("Added to favourites ❤️");
      }
    } catch (err) {
      toast.error(err.response?.data?.message || "Action failed");
    }
  };

  const handleRec = async (book) => {
    if (!isAuth) return toast.info("Please login first");
    try {
      if (recIds.has(book.id)) {
        await api.delete(`/recommendations/${book.id}`);
        setRecIds((p) => {
          const s = new Set(p);
          s.delete(book.id);
          return s;
        });
        toast.success("Recommendation removed");
      } else {
        await api.post("/recommendations", {
          bookId: book.id,
          title: book.title,
          authors: book.authors,
          thumbnail: book.thumbnail,
          description: book.description,
          publishedDate: book.publishedDate,
          language: book.language,
        });
        setRecIds((p) => new Set([...p, book.id]));
        toast.success("Recommended ⭐");
      }
    } catch (err) {
      toast.error(err.response?.data?.message || "Action failed");
    }
  };

  const loadMore = () => {
    const next = startIndex + 20;
    setStartIndex(next);
    loadBooks(category, query, next);
  };

  return (
    <div style={S.page}>
      {/* Hero */}
      <div style={S.hero}>
        <h1 style={S.heroTitle}>Discover Your Next Great Read</h1>
        <p style={S.heroSub}>
          Search millions of books, save favourites, recommend to others
        </p>
        <SearchBar onSearch={handleSearch} />
      </div>

      {/* Category Pills */}
      <div style={S.pills}>
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => handleCategory(cat)}
            style={{
              ...S.pill,
              ...(category === cat && !query ? S.pillActive : {}),
            }}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Section Header */}
      <div style={S.rowHeader}>
        <h2 style={S.sectionTitle}>
          {query ? `Results for "${query}"` : category}
        </h2>
        {totalItems > 0 && (
          <span style={S.totalCount}>{totalItems.toLocaleString()} books</span>
        )}
      </div>

      {/* Grid */}
      {loading && books.length === 0 ? (
        <div className="page-center">
          <div className="spinner" />
        </div>
      ) : books.length === 0 ? (
        <div className="page-center">
          <p>No books found. Try a different keyword.</p>
        </div>
      ) : (
        <>
          <div style={S.grid}>
            {books.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                isFav={favIds.has(book.id)}
                isRec={recIds.has(book.id)}
                onFav={handleFav}
                onRec={handleRec}
              />
            ))}
          </div>
          {books.length < totalItems && (
            <div style={{ textAlign: "center", marginTop: 40 }}>
              <button onClick={loadMore} disabled={loading} style={S.loadMore}>
                {loading ? "Loading..." : "Load More"}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

const S = {
  page: { maxWidth: 1400, margin: "0 auto", padding: "0 24px 60px" },
  hero: {
    textAlign: "center",
    padding: "56px 0 36px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 14,
  },
  heroTitle: {
    fontSize: "2.4rem",
    fontWeight: 800,
    background: "linear-gradient(135deg,#6366f1,#a78bfa)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
  },
  heroSub: { color: "#64748b", fontSize: "1rem" },
  pills: {
    display: "flex",
    gap: 10,
    flexWrap: "wrap",
    justifyContent: "center",
    marginBottom: 32,
  },
  pill: {
    padding: "8px 18px",
    borderRadius: 20,
    border: "1px solid #2d2f3e",
    background: "#1a1d2e",
    color: "#94a3b8",
    cursor: "pointer",
    fontSize: "0.85rem",
  },
  pillActive: { background: "#6366f1", color: "#fff", borderColor: "#6366f1" },
  rowHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  sectionTitle: { fontSize: "1.3rem", fontWeight: 700, color: "#e2e8f0" },
  totalCount: { color: "#64748b", fontSize: "0.85rem" },
  grid: {
    display: "grid",
    gap: 20,
    gridTemplateColumns: "repeat(auto-fill, minmax(190px, 1fr))",
  },
  loadMore: {
    padding: "12px 40px",
    background: "#1a1d2e",
    border: "1px solid #6366f1",
    borderRadius: 10,
    color: "#6366f1",
    fontWeight: 600,
    cursor: "pointer",
  },
};
